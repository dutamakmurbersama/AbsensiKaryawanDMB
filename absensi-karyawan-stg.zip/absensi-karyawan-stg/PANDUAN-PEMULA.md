# Panduan Pemula — Sistem Absensi Karyawan PT Sentralindo Teguh Gemilang

Panduan ini ditulis untuk Anda yang **belum pernah coding sama sekali**. Ikuti setiap langkah secara berurutan.

---

## Daftar Isi
1. Membuat Google Spreadsheet
2. Membuat Sheet "Absen Masuk" dan "Absen Ijin"
3. Membuat Google Apps Script
4. Menyalin Code.gs
5. Membuat Folder Google Drive untuk Foto
6. Deploy sebagai Web App
7. Menghubungkan Website dengan Google Apps Script
8. Menjalankan Website
9. Menguji Seluruh Fitur
10. Mengganti Koordinat Kantor
11. Mengubah Radius Absensi
12. Mengganti Logo Perusahaan
13. Mengganti Nama Aplikasi
14. Mengganti Warna Website
15. Mengganti Icon Aplikasi
16. Membuat Icon Ukuran 72–512 px
17. Cara Kerja PWA
18. Menampilkan Tombol Install App
19. Menginstal Aplikasi di Android
20. Menginstal Aplikasi di Windows
21. Menambahkan ke Home Screen di iPhone
22. Melihat Data di Google Spreadsheet
23. Melihat Foto di Google Drive
24. Memperbarui Aplikasi Jika Ada Perubahan Kode
25. Menghapus Cache PWA
26. Mengatasi Error yang Paling Sering Terjadi

---

## 1. Membuat Google Spreadsheet

1. Buka [sheets.google.com](https://sheets.google.com).
2. Klik **Blank (Kosong)** untuk membuat spreadsheet baru.
3. Beri nama file, misalnya **"Database Absensi STG"** (klik judul di kiri atas untuk mengubahnya).

## 2. Membuat Sheet "Absen Masuk" dan "Absen Ijin"

Anda **tidak perlu membuat header kolom secara manual** — script akan membuatnya otomatis saat pertama kali dijalankan. Yang perlu Anda lakukan:

1. Klik kanan pada tab sheet di bagian bawah (defaultnya bernama "Sheet1").
2. Pilih **Rename**, ubah namanya menjadi persis: `Absen Masuk`
3. Klik tanda **+** di pojok kiri bawah untuk menambah sheet baru.
4. Rename sheet baru tersebut menjadi persis: `Absen Ijin`

> Penulisan nama harus **persis sama** (huruf besar/kecil dan spasi), karena Code.gs mencari sheet berdasarkan nama ini.

## 3. Membuat Google Apps Script

1. Di spreadsheet Anda, klik menu **Extensions (Ekstensi) > Apps Script**.
2. Tab baru akan terbuka berisi editor kode dengan nama proyek "Untitled project" dan file default `Code.gs` berisi kode contoh.
3. Ganti nama proyek menjadi **"Backend Absensi STG"** (klik nama proyek di kiri atas).

## 4. Menyalin Code.gs

1. Hapus seluruh kode contoh di editor `Code.gs`.
2. Buka file `Code.gs` yang sudah disediakan dalam project ini.
3. Salin **seluruh isinya**, lalu tempel ke editor Apps Script.
4. Tekan ikon disket (Save) atau `Ctrl+S`.

## 5. Membuat Folder Google Drive untuk Foto

1. Buka [drive.google.com](https://drive.google.com).
2. Klik **New (Baru) > New folder**, beri nama misalnya **"Foto Absensi STG"**.
3. Buka folder tersebut, lalu salin **ID folder** dari URL browser Anda.
   - Contoh URL: `https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQrSt`
   - ID folder-nya adalah bagian setelah `/folders/`, yaitu: `1AbCdEfGhIjKlMnOpQrSt`
4. Kembali ke editor Apps Script, cari baris berikut di bagian atas `Code.gs`:
   ```
   DRIVE_FOLDER_ID: "PASTE_FOLDER_ID_GOOGLE_DRIVE_DI_SINI",
   ```
5. Ganti tulisan `PASTE_FOLDER_ID_GOOGLE_DRIVE_DI_SINI` dengan ID folder yang tadi Anda salin. Contoh:
   ```
   DRIVE_FOLDER_ID: "1AbCdEfGhIjKlMnOpQrSt",
   ```
6. Simpan (`Ctrl+S`).

## 6. Deploy sebagai Web App

1. Di editor Apps Script, klik tombol biru **Deploy** di kanan atas > **New deployment**.
2. Klik ikon gerigi (⚙️) di sebelah "Select type", pilih **Web app**.
3. Isi:
   - **Description**: Deploy pertama
   - **Execute as**: **Me** (akun Anda)
   - **Who has access**: **Anyone**
4. Klik **Deploy**.
5. Google akan meminta Anda **mengizinkan akses** (Authorize access):
   - Klik akun Google Anda.
   - Jika muncul peringatan "Google hasn't verified this app", klik **Advanced (Lanjutan)** lalu klik **Go to Backend Absensi STG (unsafe)**. Ini aman karena ini adalah script buatan Anda sendiri.
   - Klik **Allow (Izinkan)**.
6. Setelah berhasil, Anda akan melihat **Web app URL** — salin URL ini, akan digunakan pada langkah berikutnya.

> **Penting:** setiap kali Anda mengubah isi `Code.gs`, Anda harus membuat **New deployment** lagi (atau gunakan "Manage deployments" > edit versi) agar perubahan aktif di URL yang sama.

## 7. Menghubungkan Website dengan Google Apps Script

1. Buka file `script.js` menggunakan text editor (Notepad, VS Code, atau semacamnya).
2. Cari baris berikut di bagian paling atas:
   ```javascript
   SCRIPT_URL: "PASTE_URL_WEB_APP_GOOGLE_APPS_SCRIPT_DI_SINI",
   ```
3. Ganti dengan URL Web App yang Anda salin pada langkah 6. Contoh:
   ```javascript
   SCRIPT_URL: "https://script.google.com/macros/s/AKfycbx.../exec",
   ```
4. Simpan file.

## 8. Menjalankan Website

Karena website ini menggunakan HTML/CSS/JS murni (tanpa server backend seperti Node.js), Anda punya beberapa pilihan hosting gratis:

**Opsi A — GitHub Pages (disarankan, gratis & mendukung PWA):**
1. Buat akun di [github.com](https://github.com) bila belum punya.
2. Buat repository baru, unggah semua file (`index.html`, `style.css`, `script.js`, `manifest.json`, `service-worker.js`, folder `icons/`, folder `assets/`).
3. Buka **Settings > Pages**, aktifkan GitHub Pages dari branch `main`.
4. Website Anda akan aktif di alamat seperti `https://namaanda.github.io/nama-repo/`.

**Opsi B — Netlify / Vercel (drag & drop, gratis):**
1. Buka [app.netlify.com/drop](https://app.netlify.com/drop).
2. Seret (drag) seluruh folder project ke halaman tersebut.
3. Website langsung aktif dengan URL otomatis.

> PWA (install ke HP/laptop) **wajib diakses lewat HTTPS** — semua opsi di atas sudah otomatis menggunakan HTTPS.

## 9. Menguji Seluruh Fitur

1. Buka URL website Anda di HP atau laptop.
2. Coba tombol **ABSEN MASUK**:
   - Isi nama, bagian, dan shift.
   - Tekan **Ambil Lokasi** (izinkan akses lokasi saat diminta browser).
   - Jika berada di luar radius kantor, kotak merah akan muncul — ini normal karena Anda belum berada di lokasi kantor sungguhan.
   - Tekan **Buka Kamera**, ambil selfie, lalu **Gunakan Foto Ini**.
   - Tekan **Kirim Absen**.
3. Buka Google Spreadsheet Anda — baris baru seharusnya sudah muncul di sheet "Absen Masuk".
4. Uji juga tombol **ABSEN IJIN** dan pastikan data masuk ke sheet "Absen Ijin".

## 10. Mengganti Koordinat Kantor

1. Buka Google Maps, cari lokasi kantor/pabrik Anda.
2. Klik kanan tepat di titik lokasi, klik angka koordinat yang muncul untuk menyalinnya (contoh: `-6.300000, 107.150000`).
3. Buka `script.js`, cari:
   ```javascript
   officeLat: -6.300000,
   officeLng: 107.150000,
   ```
4. Ganti dengan koordinat kantor Anda, lalu simpan.

## 11. Mengubah Radius Absensi

Di `script.js`, cari baris:
```javascript
radiusMeters: 100,
```
Ganti angka `100` sesuai kebutuhan (dalam satuan meter), lalu simpan.

## 12. Mengganti Logo Perusahaan

Ganti file `assets/logo.png` dengan logo perusahaan Anda sendiri. Gunakan nama file yang **sama persis** (`logo.png`) agar tidak perlu mengubah kode. Disarankan gambar berbentuk persegi (misalnya 512x512 px) dengan latar transparan.

## 13. Mengganti Nama Aplikasi

Buka `manifest.json`, ubah:
```json
"name": "Sistem Absensi Karyawan - PT Sentralindo Teguh Gemilang",
"short_name": "Absensi STG",
```
`short_name` adalah nama yang tampil di bawah ikon aplikasi setelah di-install, sebaiknya singkat (maksimal 12 karakter).

## 14. Mengganti Warna Website

Buka `style.css`, di bagian paling atas terdapat "design tokens":
```css
--color-primary: #1D4ED8;
--color-primary-dark: #1739A8;
--color-primary-light: #3B82F6;
--color-sky: #0EA5E9;
```
Ganti kode warna (hex) sesuai identitas perusahaan Anda. Semua elemen di website akan otomatis mengikuti warna baru ini.

Jangan lupa juga ubah `theme_color` di `manifest.json` dan tag `<meta name="theme-color">` di `index.html` agar konsisten.

## 15. Mengganti Icon Aplikasi

Icon default berupa gambar bertema jam/lokasi warna biru. Untuk menggantinya dengan logo perusahaan Anda sendiri, ikuti langkah nomor 16 di bawah.

## 16. Membuat Icon Ukuran 72–512 px

Anda perlu 8 ukuran: 72, 96, 128, 144, 152, 192, 384, dan 512 piksel, semua berformat PNG persegi.

**Cara termudah (tanpa software desain):**
1. Buka [favicon.io/favicon-converter](https://favicon.io/favicon-converter/) atau [realfavicongenerator.net](https://realfavicongenerator.net/).
2. Unggah logo perusahaan Anda (idealnya minimal 512x512 px).
3. Unduh hasilnya, lalu ganti file-file di dalam folder `icons/` dengan nama yang sama persis:
   `icon-72.png`, `icon-96.png`, `icon-128.png`, `icon-144.png`, `icon-152.png`, `icon-192.png`, `icon-384.png`, `icon-512.png`.

## 17. Cara Kerja PWA

PWA (Progressive Web App) memungkinkan website berperilaku seperti aplikasi native:
- **manifest.json** memberi tahu browser nama aplikasi, warna tema, dan ikon yang digunakan saat di-install.
- **service-worker.js** berjalan di latar belakang, menyimpan (cache) file-file aplikasi di perangkat sehingga aplikasi tetap bisa dibuka meski koneksi internet lambat, dan tampilan halaman langsung muncul cepat tanpa perlu memuat ulang semua file dari server setiap saat.
- Data absen (ke Google Apps Script) **selalu diambil langsung dari internet**, tidak pernah disimpan di cache, agar data yang terkirim selalu yang terbaru.

## 18. Menampilkan Tombol Install App

Tombol **"Install Aplikasi"** di pojok kanan atas akan otomatis muncul jika:
- Website dibuka lewat **HTTPS** (bukan `file://` atau HTTP biasa).
- Browser mendukung instalasi PWA (Chrome, Edge, Samsung Internet di Android/Windows).
- `manifest.json` dan `service-worker.js` berhasil dimuat tanpa error.

Jika browser tidak mendukung (misalnya Safari versi lama), tombol akan otomatis tersembunyi — pengguna iPhone tetap bisa install lewat cara manual (lihat poin 21).

## 19. Menginstal Aplikasi di Android

1. Buka website menggunakan **Google Chrome**.
2. Tunggu tombol **"Install Aplikasi"** muncul di pojok kanan atas, lalu tekan.
   - Atau: tekan menu titik tiga (⋮) di Chrome > **Install app** / **Add to Home screen**.
3. Konfirmasi instalasi. Ikon aplikasi akan muncul di layar utama dan daftar aplikasi HP.

## 20. Menginstal Aplikasi di Windows

1. Buka website menggunakan **Google Chrome** atau **Microsoft Edge**.
2. Klik ikon **install** (biasanya berbentuk layar dengan panah) di ujung kanan address bar, atau tekan tombol **"Install Aplikasi"** di website.
3. Klik **Install**. Aplikasi akan muncul di Start Menu dan bisa dibuka seperti aplikasi Windows biasa, tanpa address bar browser.

## 21. Menambahkan ke Home Screen di iPhone

iPhone (Safari) belum mendukung tombol install otomatis, jadi harus manual:
1. Buka website menggunakan **Safari** (bukan Chrome).
2. Tekan ikon **Share/Bagikan** (kotak dengan panah ke atas) di bagian bawah layar.
3. Gulir ke bawah, pilih **"Add to Home Screen"** (Tambah ke Layar Utama).
4. Tekan **Add**. Ikon aplikasi akan muncul di layar utama iPhone.

## 22. Melihat Data di Google Spreadsheet

Buka kembali Google Spreadsheet Anda kapan saja — setiap absen masuk dan absen ijin yang terkirim dari website akan otomatis muncul sebagai baris baru di sheet **"Absen Masuk"** atau **"Absen Ijin"**, lengkap dengan waktu server, koordinat, dan link foto.

## 23. Melihat Foto di Google Drive

Setiap kolom **"Link Foto"** di sheet "Absen Masuk" berisi link ke foto selfie karyawan. Klik link tersebut untuk membuka foto langsung dari folder Google Drive yang Anda tentukan di langkah 5.

## 24. Memperbarui Aplikasi Jika Ada Perubahan Kode

**Jika Anda mengubah `Code.gs`:**
1. Buka kembali editor Apps Script.
2. Klik **Deploy > Manage deployments**.
3. Klik ikon pensil (Edit) pada deployment aktif.
4. Pada "Version", pilih **New version**, lalu klik **Deploy**.
   - URL Web App tetap sama, tidak perlu mengganti `SCRIPT_URL` di `script.js`.

**Jika Anda mengubah `index.html`, `style.css`, atau `script.js`:**
1. Unggah ulang file yang berubah ke hosting Anda (GitHub Pages/Netlify).
2. Buka `service-worker.js`, naikkan angka versi cache, misalnya dari:
   ```javascript
   const CACHE_NAME = "absensi-stg-v1";
   ```
   menjadi:
   ```javascript
   const CACHE_NAME = "absensi-stg-v2";
   ```
   Ini memastikan pengguna yang sudah meng-install aplikasi mendapatkan versi terbaru, bukan versi lama dari cache.

## 25. Menghapus Cache PWA Jika Aplikasi Tidak Memperbarui Data

Jika setelah update aplikasi masih menampilkan tampilan lama:

**Di Android/Windows (Chrome):**
1. Buka `chrome://apps` atau buka menu aplikasi.
2. Klik kanan pada aplikasi > **Uninstall**, lalu install ulang dari website.
   - Atau: buka Chrome > Settings > Privacy and security > Clear browsing data > centang "Cached images and files" > Clear data.

**Di iPhone:**
1. Hapus ikon aplikasi dari layar utama (tekan lama > Remove App).
2. Buka Safari, buka website kembali, lalu tambahkan ke Home Screen lagi (langkah 21).

## 26. Mengatasi Error yang Paling Sering Terjadi

| Masalah | Penyebab & Solusi |
|---|---|
| Muncul pesan **"Belum Terhubung"** saat kirim absen | `SCRIPT_URL` di `script.js` belum diganti dengan URL Web App yang benar. Lihat langkah 7. |
| Absen terkirim tapi foto tidak muncul di Drive | `DRIVE_FOLDER_ID` di `Code.gs` salah atau belum diganti. Lihat langkah 5. Pastikan juga sudah melakukan **New deployment** setelah mengubah `Code.gs`. |
| Tombol **"Kirim Absen"** selalu error / tidak merespons | Periksa apakah "Who has access" pada deployment Web App sudah diset ke **Anyone** (bukan "Only myself"). Lihat langkah 6. |
| Lokasi selalu dianggap "di luar radius" padahal sudah di kantor | Koordinat `officeLat`/`officeLng` di `script.js` belum sesuai lokasi kantor asli, atau radius terlalu kecil. Lihat langkah 10–11. GPS HP juga bisa memiliki margin kesalahan 10–30 meter di dalam gedung. |
| Kamera tidak bisa dibuka | Pastikan website diakses lewat **HTTPS**, browser mendukung, dan izin kamera belum diblokir (cek ikon gembok di address bar). |
| Tombol **"Install Aplikasi"** tidak pernah muncul | Pastikan diakses via HTTPS, `manifest.json` & `service-worker.js` termuat tanpa error (cek lewat DevTools > Console), dan aplikasi belum pernah di-install sebelumnya di perangkat tersebut. |
| Data tidak masuk ke sheet yang benar | Pastikan nama sheet **persis** `Absen Masuk` dan `Absen Ijin` (huruf besar/kecil dan spasi harus sama). |
| Muncul "Anda sudah melakukan Absen Masuk hari ini" padahal belum | Periksa apakah ada baris lama di sheet dengan nama yang sama dan tanggal hari ini — mungkin data uji coba sebelumnya belum dihapus. |

---

Jika Anda mengikuti seluruh langkah di atas secara berurutan, sistem absensi ini sudah siap digunakan oleh seluruh karyawan PT Sentralindo Teguh Gemilang.
